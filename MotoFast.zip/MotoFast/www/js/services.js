angular.module('starter.services', [])

//Os serviços vão aqui

.factory('firebaseData',function($firebase){
	 var config = {
    apiKey: "AIzaSyANCjdijAus8KWPa_pnprn33B4_imDEwgc",
    authDomain: "motofast-6e5db.firebaseapp.com",
    databaseURL: "https://motofast-6e5db.firebaseio.com",
    storageBucket: "motofast-6e5db.appspot.com",
    messagingSenderId: "52333528676"
  };
  firebase.initializeApp(config);



  var ref = firebase.database().ref();
  
  return {
  	ref: function(){
  		return ref;
  	},
 	refUsuarios : function(){
 		return ref.child('usuarios');
 	},
 	refProfissionais: function(){
 		return ref.child('profissionais');
 	}
 }
})
