angular.module('starter.controllers', [])

  .controller('UsuarioCtrl', function ($scope,firebaseData,$firebaseArray,$rootScope) {
    $scope.usuarios = $firebaseArray(firebaseData.refUsuarios())
    $scope.addUsuario = function (e) {
      
      $scope.usuarios.$add({
        Nome: $scope.nome,
        End_atual: $scope.end_atual,
        End_destino: $scope.end_destino,
        Ref: $scope.ref,
        Tel: $scope.tel
      });
      $scope.nome = "";
      $scope.end_atual = "";
      $scope.end_destino = "";
      $scope.ref = "";
      $scope.tel = 0;
      
    };
  })

  .controller('ProfissionalCtrl', function ($scope,firebaseData,$firebaseArray,$rootScope) {
    $scope.profissionais = $firebaseArray(firebaseData.refProfissionais())
    $scope.addProfissional = function (e) {
     
      $scope.profissionais.$add({
        Placa: $scope.placa,
        Senha: $scope.senha
      });
      $scope.placa = "";
      $scope.senha = "";
    };
  })

  .controller('AppCtrl', function ($scope,Auth){
    Auth.$onAuth(function(authData){
      if(authData === null){
        console.log("Usuário não autenticado.")
        }else{
          cons.log("Usuário autenticado.");
          console.log(authData)
        }
      $scope.authData = authData;
    });

    $scope.login = function(authMethod){
      Auth.$authWithOAuthRedirect(authMethod).then(function(authData){

      }).catch(function(error){
        if(error.code === 'TRANSPORT_UNAVAILABLE'){
          Auth.$authWithOAuthPopup(authMethod).then(function(authData){});
        }else{
          console.log(error);
        }
      })
    };
  })